"""Optional headless GUI pass preserving colours and visibility in native CAD."""
import sys,os,json
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
sys.path.append('/Applications/FreeCAD.app/Contents/Resources/lib')
import FreeCAD as App,FreeCADGui as Gui
from common import MATERIALS
out=Path(__file__).resolve().parent.parent
Gui.showMainWindow()
import ImportGui
print('Opening document',flush=True)
doc=App.openDocument(str(out/'editable.FCStd'))
print('Opened document',flush=True)
manifest=json.loads((out/'model-manifest.json').read_text())
main=[];fit=[]
for p in manifest['parts']:
 o=doc.getObject(p['objectName'])
 o.ViewObject.ShapeColor=tuple(MATERIALS[p['material']]['color'])
 o.ViewObject.LineColor=(.08,.08,.09)
 o.ViewObject.DisplayMode='Shaded'
 o.ViewObject.Visibility=p['group'] not in ['Fit kit','Cable section']
 if p['group']=='Fit kit':fit.append(o)
 elif p['group']!='Cable section':main.append(o)
for o in doc.Objects:
 if o.TypeId=='App::DocumentObjectGroup' and o.Label in ['Fit kit','Cable section']:o.ViewObject.Visibility=False
print('Saving colours',flush=True)
doc.recompute();doc.save()
print('Saved colours',flush=True)
import Import
Import.export(main,str(out/'assembly.step'))
Import.export(fit,str(out/'fit-kit.step'))
for side in ['L','R']:
 Import.export([o for o in main if o.Label.startswith(side+' | ') and '150 mm' not in o.Label],str(out/('earbud-'+side+'.step')))
print('Styled CAD and STEP files saved',flush=True)
