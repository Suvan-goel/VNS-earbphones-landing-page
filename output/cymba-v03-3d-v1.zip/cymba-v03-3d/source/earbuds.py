from common import *

def body_envelope():
    return Part.makeLoft([ellipse(rx,ry,z) for z,rx,ry in [(-7,7,9),(-6,9.6,12),(-4,11.6,14.5),(-1,12.4,15),(2,12,14.3),(5,11,13),(6,10,11.5)]],True,False)

def tip_geometry(radius=6.2):
    s=radius/6.2
    # Continuous acoustic bore, flexible bell wall; all dimensions provisional.
    profile=[(3.25,0,2.9),(4.1*s,0,3.5),(5.65*s,0,5.2),(radius,0,6.8),(5.75*s,0,8.4),(4.1*s,0,10.2),(2.1,0,10.2),(2.1,0,8.9),(3.4*s,0,8.9),(4.8*s,0,7.7),(5.15*s,0,6.8),(4.8*s,0,5.4),(3.25,0,4.1),(3.25,0,2.9)]
    face=Part.Face(Part.makePolygon([V(*p) for p in profile]))
    silicone=face.revolve(V(),V(0,0,1),360)
    # Two discontinuous polymer sectors with 60-degree insulation gaps.
    band=[(5.94*s,0,5.8),(radius,0,6.8),(5.75*s,0,8.4),(5.42*s,0,8.8),(5.02*s,0,8.8),(5.35*s,0,8.4),(radius-.40,0,6.8),(5.54*s,0,5.8),(5.94*s,0,5.8)]
    f=Part.Face(Part.makePolygon([V(*p) for p in band]))
    pads=[]
    for start in [20,200]:
        p=f.revolve(V(),V(0,0,1),120); p.rotate(V(),V(0,0,1),start)
        silicone=silicone.cut(p); pads.append(p)
    return silicone,pads

def fin_geometry(scale=1):
    pts=[(-8,8),(-12.3,13),(-12.3,22),(-9.3,29),(-5.4,32),(-1.2,30),(-1.4,27),(-4.5,23),(-3.8,17),(.0,12)]
    pts=[((x+5)*scale-5,(y-10)*scale+10,-2.5) for x,y in pts]
    f=Part.Face(spline_wire(pts)).extrude(V(0,0,5.1))
    # Always 75.398 mm2 independent of fit size; pad location moves with fin size.
    px=-7; py=21.5+(scale-1)*12
    f=f.fuse(oval(4.5,6.5,5.1,(px,py,-2.5))).removeSplitter()
    try: f=f.makeFillet(.45,f.Edges)
    except: pass
    pocket=oval(4.15,6.15,1,(px,py,2.1))
    f=f.cut(pocket)
    pad=oval(4,6,.5,(px,py,2.1))
    f=f.cut(body_envelope())
    return f,pad

def build_bud(side):
    group='Left earbud' if side=='L' else 'Right earbud'
    shift=-31 if side=='L' else 31
    mirror=side=='R'
    def place(s):
        if mirror:
            s=s.mirror(V(),V(1,0,0))
        return moved(s,(shift,0,0))
    def put(name,s,mat='shell',role='',ex=(0,0,0),source='Spec p.3-5; dimensions provisional',notes=''):
        if mirror: ex=(-ex[0],ex[1],ex[2])
        return add(side+' | '+name,place(s),mat,group,role or name,ex,source,notes)
    def nozzle(s):
        s=s.copy();s.rotate(V(),V(0,1,0),15);s.translate(V(4.8,-4,5.6));return s
    profiles=[(-7,7,9),(-6,9.6,12),(-4,11.6,14.5),(-1,12.4,15),(2,12,14.3),(5,11,13),(6,10,11.5)]
    outer=Part.makeLoft([ellipse(rx,ry,z) for z,rx,ry in profiles],True,False)
    inner=Part.makeLoft([ellipse(rx,ry,z) for z,rx,ry in [(-5.6,6.5,8.5),(-4.8,9,11.6),(-2,10.9,13.5),(1.5,10.6,12.8),(4.8,9.1,10.5)]],True,False)
    shell=outer.cut(inner)
    upper=shell.common(Part.makeBox(60,70,30,V(-30,-30,-2.4)))
    lower=shell.common(Part.makeBox(60,70,30,V(-30,-30,-32.65)))
    # Functional pockets through the inner cap.
    ret_ry=100/(math.pi*5.6)
    pockets=[oval(5.75,ret_ry+.15,3,(-4.5,-4,4.5)),oval(2.65,2.45,3,(4.4,6.5,4.5)),rounded_box(5.6,4.8,3,1,(-4.3,6.2,4.5)),oval(1.65,2.25,3,(8,1.4,4.5)),nozzle(cylinder(3.4,6,(0,0,-1)))]
    for p in pockets: upper=upper.cut(p)
    # Cable outlet through shell bottom and mounting boss.
    upper=upper.cut(cylinder(1.25,10,(0,-20,0),(0,1,0)))
    put('Inner housing shell',upper,'shell','Hollow contact-side housing; recessed independent contacts',(0,0,12),notes='Approximate 1.2 mm nominal wall. Fit and wall thickness are unvalidated assumptions.')
    put('Outer faceplate',lower,'face','Removable outer housing and cosmetic faceplate',(0,0,-16))
    rim=oval(12.1,14.8,.25,(0,0,-2.65)).cut(oval(10.9,13.5,1,(0,0,-3)))
    put('Champagne seam rim',rim,'gold','Assumed cosmetic shell interface',(0,0,-6),source='Visual finish assumption')
    gasket=oval(10.95,13.55,.4,(0,0,-2.5)).cut(oval(10.55,13.15,1,(0,0,-2.8)))
    put('Housing perimeter gasket',gasket,'silicone','Concept sealing element',(0,0,-5),notes='Represents IP57 design target only; no ingress validation.')
    # Inner cap contact inserts flush at z=6.
    for name,rx,ry,xy,mat,role in [
      ('Stimulation return',5.6,ret_ry,(-4.5,-4),'stim','Cavum conchae return; independent from EEG reference; 100 mm² planar face'),
      ('EEG concha reference',2.5,2.3,(4.4,6.5),'eeg','Dry conductive polymer EEG reference on concha'),
      ('DRL contact' if side=='R' else 'Reserved DRL contact',1.5,2.1,(8,1.4),'eeg','Shared driven ground at right tragus' if side=='R' else 'Inactive mirrored DRL pad to preserve identical hardware; assumption')]:
        x,y=xy
        carrier=oval(rx+.14,ry+.14,1.2,(x,y,4.8)).cut(oval(rx,ry,1.5,(x,y,4.7)))
        put(name+' insulator',carrier,'silicone',ex=(0,0,14))
        p=put(name,oval(rx,ry,.7,(x,y,5.3)),mat,role,(0,0,16))
        p['contactAreaMm2']=math.pi*rx*ry
        put(name+' spring termination',cylinder(.5,2,(x,y,3.3)),'gold','Representative independent electrode termination',(0,0,4))
    # Sensor window and discrete optical compartments; two emitters + receiver.
    frame=rounded_box(5.5,4.7,1.2,.9,(-4.3,6.2,4.8))
    openings=[]
    for x,y,r in [(-5.6,6.2,.64),(-3.2,5.35,.58),(-3.2,7,.65)]:
        hole=cylinder(r,2,(x,y,4.6)); frame=frame.cut(hole)
        put('PPG window '+str(len(openings)+1),cylinder(r,.32,(x,y,5.68)),'glass','Flush optical window',(0,0,17));openings.append((x,y,r))
    put('PPG opaque optical baffle',frame,'silicone','Optical separation of emitters and photodiode',(0,0,14))
    for name,(x,y,r),mat in zip(['Photodiode','Infrared LED 256 Hz','Green fallback LED'],openings,['chip','chip','green']):
        put('PPG '+name,cylinder(r*.8,.6,(x,y,4.2)),mat,'Representative '+name+' package',(0,0,7))
    # Removable fin has active electrode at its cymba-facing surface.
    fin,pad=fin_geometry()
    put('Medium silicone cymba fin',fin,'silicone','Interchangeable M retention fin',(0,14,0))
    ap=put('Cymba active stimulation electrode',pad,'stim','Ag/AgCl-coated compliant contact on fin; 75.398 mm² planar face',(0,17,6),notes='Specified range 50–100 mm². Contact pressure and anatomical coverage are unvalidated.')
    ap['contactAreaMm2']=math.pi*4*6
    for x in [-8.5,-6.3]: put('Fin connector contact '+str(x),cylinder(.55,1.5,(x,11,1)),'gold','Assumed removable fin electrical interface',(0,8,0))
    # Nozzle, central bore, retention ridge, tip and two isolated sectors.
    noz=cylinder(3.15,5.4,(0,0,-.4)).cut(cylinder(2.05,7,(0,0,-1)))
    put('Acoustic nozzle',nozzle(noz),'shell','Angled 15-degree hollow sound path',(4,0,15),notes='Angle, diameter and insertion depth provisional.')
    put('Tip retention bead',nozzle(cylinder(3.4,.6,(0,0,3.5)).cut(cylinder(3.05,1,(0,0,3.3)))),'silicone',ex=(4,0,15))
    tip,pads=tip_geometry()
    put('Medium removable silicone tip',nozzle(tip),'silicone','M size bell tip with open acoustic bore',(9,0,30))
    for i,pad in enumerate(pads):
        put('EEG canal signal '+str(i+1),nozzle(pad),'eeg','Independent dry conductive-polymer sector on tip',(9,0,30),notes='Two 120° sectors; 60° insulating gaps. Connector and routing geometry provisional.')
    # Acoustic mesh represented by crossed narrow wires, actual bore remains visible.
    wires=[]
    for d in [-1.5,-1,-.5,0,.5,1,1.5]:
        half=math.sqrt(1.95**2-d*d)
        wires.append(cylinder(.035,2*half,(-half,d,9.8),(1,0,0)))
        wires.append(cylinder(.035,2*half,(d,-half,9.8),(0,1,0)))
    put('Acoustic outlet mesh',nozzle(Part.makeCompound(wires)),'steel','Representative acoustic debris screen',(9,0,30))
    # 8.8 mm driver seats behind the angled nozzle.
    driver=cylinder(4.4,2.2,(0,0,-4)).cut(cylinder(3.75,1.1,(0,0,-2.8)))
    put('8.8 mm speaker basket',nozzle(driver),'steel','Representative standard dynamic driver; diameter assumed',(0,0,-3))
    put('Speaker diaphragm',nozzle(cylinder(3.7,.08,(0,0,-2.7))),'face','Hub-driven audio diaphragm',(0,0,2))
    put('Speaker magnetic motor',nozzle(cylinder(2.7,1.2,(0,0,-5.2))),'chip','Representative audio driver motor',(0,0,-5))
    # Local sensor board only; main electronics remain in hub.
    pcb=rounded_box(15,20,.7,2,(-1,1,-.9))
    pcb=pcb.cut(nozzle(cylinder(4.65,10,(0,0,-9)))).common(inner)
    put('Sensor PCB',pcb,'pcb','Local PPG and IMU board; no main processor or EEG amplifier',(0,0,-8))
    put('6-axis IMU',rounded_box(2.7,2.7,.9,.2,(4,7,-.2)),'chip','100 Hz IMU; representative package',(0,0,-8))
    put('PPG sensor carrier',rounded_box(5.4,4.5,.7,.4,(-4.3,6.2,3.5)),'pcb','Optical sensor daughterboard',(0,0,5))
    for j in range(7):
        put('Sensor passive '+str(j+1),rounded_box(.8,1.2,.4,.1,(-6+(j%4)*2,2+(j//4)*2,-.2)),'chip','Representative passive component',(0,0,-8))
    for j in range(12):
        put('Cable termination '+str(j+1),rounded_box(.5,1.6,.15,.1,(-5.5+j,-7.8,-.18)),'gold','12-conductor ear branch termination',(0,0,-8))
    # Cable boot, individually molded strain-relief grooves.
    boot=Part.makeCone(2.4,1.25,7,V(0,-13.5,0),V(0,-1,0)).cut(cylinder(1.0,8,(0,-13,0),(0,-1,0)))
    put('Cable strain relief',boot,'silicone','Cable movement restraint',(0,-4,0))
    for yy in [-15.5,-17,-18.5]:
        rr=2.4-(abs(yy)-13.5)/7*1.15
        ring=Part.makeTorus(rr,.10,V(0,yy,0),V(0,1,0))
        put('Strain relief groove '+str(yy),ring,'face','Molded cable relief detail',(0,-4,0))
    # Internal electrode harness represents separate paths, not a wiring schematic.
    for i,xy in enumerate([(-4.5,-4),(4.4,6.5),(8,1.4)]):
        x,y=xy
        wire,_=tube([(x,y,3.3),(x,y,2.6+i*.2),(-7,2-i,2.1+i*.2),(-6,-7,1.2+i*.3)],.17)
        put('Electrode lead '+str(i+1),wire,'copper','Illustrative independent contact lead',(0,0,-3))
    # Cut actual seats for inserted seal, boot and optical carrier.
    registered={p['name'].split(' | ',1)[1]:p for p in PARTS if p['group']==group}
    housing=registered['Inner housing shell']
    for key in ['Housing perimeter gasket','Cable strain relief','PPG sensor carrier']:
        housing['shape']=housing['shape'].cut(registered[key]['shape'])
    return {'side':side,'bodyEnvelopeMm':[24.8,30,13],'activeAreaMm2':math.pi*24,'returnAreaMm2':100,'tipAngleDegrees':15,'cableExit':[shift,-20.5,0]}

def build_fit_kit():
    for i,(label,diam) in enumerate([('XS',10),('S',11.2),('M',12.4),('L',13.6),('XL',14.8)]):
        s,pads=tip_geometry(diam/2); xyz=(-105+i*20,-180,0)
        add('Fit kit | '+label+' tip',moved(s,xyz),'silicone','Fit kit',label+' interchangeable tip; provisional '+str(diam)+' mm diameter',source='Spec p.1: five tip sizes; dimensions assumed')
        for j,p in enumerate(pads): add('Fit kit | '+label+' EEG '+str(j+1),moved(p,xyz),'eeg','Fit kit','Two separate conductive polymer sectors')
    for i,(label,scale) in enumerate([('S',.94),('M',1),('L',1.10)]):
        s,p=fin_geometry(scale);xyz=(-100+i*30,-240,0)
        add('Fit kit | '+label+' fin',moved(s,xyz),'silicone','Fit kit','Interchangeable fin; provisional geometry',source='Spec p.1: three fin sizes')
        a=add('Fit kit | '+label+' cymba electrode',moved(p,xyz),'stim','Fit kit','75.398 mm² planar contact for each fin size');a['contactAreaMm2']=math.pi*24
