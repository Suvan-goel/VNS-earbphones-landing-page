"""Create a single-file offline review with all libraries and model embedded."""
from pathlib import Path
import re,json,base64
out=Path(__file__).resolve().parent.parent
encode=lambda b:'data:text/javascript;base64,'+base64.b64encode(b).decode()
imports={}
for key,file in [('three','three.module.js'),('OrbitControls','OrbitControls.js'),('BufferGeometryUtils','BufferGeometryUtils.js'),('GLTFLoader','GLTFLoader.js')]:
 text=(out/'vendor'/file).read_text().replace("'./BufferGeometryUtils.js'","'BufferGeometryUtils'")
 imports[key]=encode(text.encode())
html=(out/'index.html').read_text()
html=re.sub(r'<script type="importmap">.*?</script>','<script type="importmap">'+json.dumps({'imports':imports})+'</script>',html,flags=re.S)
js=(out/'viewer.js').read_text().replace("'./vendor/OrbitControls.js'","'OrbitControls'").replace("'./vendor/GLTFLoader.js'","'GLTFLoader'")
url='data:model/gltf-binary;base64,'+base64.b64encode((out/'assembly.glb').read_bytes()).decode()
js=js.replace("'./assembly.glb'",json.dumps(url))
html=re.sub(r'<script type="module" src="./viewer.js".*?</script>',lambda m:'<script type="module">'+js+'</script>',html,flags=re.S)
(out/'model-review.html').write_text(html)
print('Offline viewer:',len(html),'bytes')
