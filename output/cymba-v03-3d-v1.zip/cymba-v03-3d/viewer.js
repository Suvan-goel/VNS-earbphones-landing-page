import * as THREE from 'three';
import { OrbitControls } from './vendor/OrbitControls.js';
import { GLTFLoader } from './vendor/GLTFLoader.js';

const $ = id => document.getElementById(id);
const container = $('canvas-container');
const focusButtons = [...document.querySelectorAll('[data-focus]')];
const views = {
  left: { title: 'Left earbud', subtitle: 'Contact surfaces & internal architecture', number: '01 / Anatomy', groups: ['Left earbud'], facts: [['Active electrode', '75.4 mm² nominal'], ['Return electrode', '100 mm² nominal'], ['Dimensional units', 'Millimetres']], footnote: 'Nominal contact areas follow the specification. Actual tissue contact depends on fit and compression.' },
  right: { title: 'Right earbud', subtitle: 'Mirrored hardware · shared DRL', number: '02 / Anatomy', groups: ['Right earbud'], facts: [['Active electrode', '75.4 mm² nominal'], ['Return electrode', '100 mm² nominal'], ['Default role', 'Sensing']], footnote: 'Both earbuds contain stimulation hardware. The right earbud defaults to sensing; the assembly shares one DRL reference.' },
  hub: { title: 'Control hub', subtitle: 'Enclosure, connections & electronics packaging', number: '03 / Architecture', groups: ['Hub'], facts: [['Assembly', 'Control hub'], ['Dimensional units', 'Millimetres']], footnote: 'Internal placement is an engineering packaging proposal. Electronic parts represent spatial envelopes.' },
  system: { title: 'Complete system', subtitle: 'Bilateral earbuds, cable harness & control hub', number: '04 / System', groups: ['Left earbud', 'Right earbud', 'Hub', 'Cable', 'System'], facts: [['Earbud branches', '150 mm each'], ['Main cable', '1,000 mm'], ['Cable arrangement', 'Coiled for display']], footnote: 'Cable routing is posed for inspection. Specified lengths are preserved in the CAD construction.' },
  fit: { title: 'Fit kit', subtitle: 'Interchangeable fit components', number: '05 / Fit', groups: ['Fit kit'], facts: [['Tip sizes', '5'], ['Fin sizes', '3'], ['Dimensional units', 'Millimetres']], footnote: 'Fit variants are shown separately. Individual part notes distinguish specified sizes from assumed geometry.' },
  cable: { title: 'Cable cross section', subtitle: 'Conductor arrangement & shielding', number: '06 / Construction', groups: ['Cable section'], facts: [['Detail', 'Cable construction'], ['Dimensional units', 'Millimetres']], footnote: 'A short inspection sample illustrates cable structure. It is separate from the full cable harness.' }
};

let renderer, scene, camera, controls, model;
let parts = [], visibleParts = [], selected = null, focus = 'left';
let showShells = true, explosion = 0, transition = null;
const basePositions = new Map();
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const axes = ['x', 'y', 'z'].map((name, index) => ({ name, vector: new THREE.Vector3(index === 0 ? 1 : 0, index === 1 ? 1 : 0, index === 2 ? 1 : 0), line: $(`axis-${name}`), label: $(`axis-${name}-label`) }));
const inverseCamera = new THREE.Quaternion();
const axisVector = new THREE.Vector3();
let pointerStart;

function fail(message, error) {
  console.error(error || message);
  $('loading').classList.add('error');
  $('loading-text').textContent = message;
  $('loading-links').hidden = false;
  document.querySelectorAll('.focus-button,.controls button,.controls input').forEach(el => el.disabled = true);
}

function studioEnvironment() {
  const width = 512, height = 256, data = new Float32Array(width * height * 4);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const u = x / width, v = y / height;
    const top = Math.max(0, 1 - v * 1.7);
    const softbox = 3.5 * Math.exp(-(((u - .25) / .12) ** 6 + ((v - .31) / .23) ** 6));
    const rim = 2 * Math.exp(-(((u - .75) / .06) ** 6 + ((v - .42) / .22) ** 6));
    const light = .22 + top * .42 + softbox + rim;
    const offset = (y * width + x) * 4;
    data[offset] = light * 1.025; data[offset + 1] = light * 1.02; data[offset + 2] = light; data[offset + 3] = 1;
  }
  const texture = new THREE.DataTexture(data, width, height, THREE.RGBAFormat, THREE.FloatType);
  texture.mapping = THREE.EquirectangularReflectionMapping;
  texture.needsUpdate = true;
  const generator = new THREE.PMREMGenerator(renderer);
  const environment = generator.fromEquirectangular(texture).texture;
  texture.dispose(); generator.dispose();
  return environment;
}

function textValue(value) {
  if (Array.isArray(value)) return value.join('; ');
  if (value && typeof value === 'object') return Object.entries(value).map(([key, val]) => `${key}: ${val}`).join('; ');
  return value == null ? '' : String(value);
}

function metadata(mesh) {
  let meta = {}, current = mesh;
  const chain = [];
  while (current && current !== model?.parent) { chain.push(current); current = current.parent; }
  chain.reverse().forEach(node => Object.assign(meta, node.userData || {}));
  meta.name = meta.name || mesh.name || 'Unnamed component';
  meta.group = meta.group || inferGroup(meta.name);
  return meta;
}

function inferGroup(name) {
  if (/cross.section|cable.section/i.test(name)) return 'Cable section';
  if (/fit.kit|fit.variant|size.[sl]/i.test(name)) return 'Fit kit';
  if (/left|^L[_ -]/i.test(name)) return 'Left earbud';
  if (/right|^R[_ -]/i.test(name)) return 'Right earbud';
  if (/hub|battery|controller/i.test(name)) return 'Hub';
  if (/cable|wire|y.split/i.test(name)) return 'Cable';
  return 'System';
}

function isShell(mesh) {
  const meta = mesh.userData.spec;
  return /shell|housing|enclosure|faceplate|outer face|lid|rear cover|front cover/i.test(`${meta.name} ${meta.role} ${meta.material || ''}`);
}

function currentBox() {
  const box = new THREE.Box3();
  visibleParts.forEach(mesh => box.expandByObject(mesh));
  return box;
}

function measure(mesh) {
  mesh.geometry.computeBoundingBox();
  const box = mesh.geometry.boundingBox.clone().applyMatrix4(mesh.matrixWorld);
  return box.getSize(new THREE.Vector3()).multiplyScalar(1000);
}

function dimensions(size) {
  return [size.x, size.y, size.z].map(n => n >= 100 ? n.toFixed(0) : n.toFixed(1)).join(' × ');
}

function updateFacts() {
  const view = views[focus];
  const rows = view.facts.slice();
  if (visibleParts.length) {
    const size = currentBox().getSize(new THREE.Vector3()).multiplyScalar(1000);
    if (explosion === 0) rows.push(['Model envelope', `${dimensions(size)} mm`]);
    $('envelope').textContent = explosion > 0 ? 'Exploded layout · millimetres' : `${dimensions(size)} mm · model envelope`;
  }
  $('facts').replaceChildren(...rows.map(([label, value]) => {
    const row = document.createElement('div'); row.className = 'fact';
    const dt = document.createElement('dt'); dt.textContent = label;
    const dd = document.createElement('dd'); dd.textContent = value;
    row.append(dt, dd); return row;
  }));
  $('fact-footnote').textContent = view.footnote;
}

function updatePartList() {
  $('part-count').textContent = String(visibleParts.length).padStart(2, '0');
  const buttons = visibleParts.map(mesh => {
    const button = document.createElement('button');
    button.className = 'part-button';
    button.textContent = mesh.userData.spec.name;
    button.setAttribute('aria-pressed', String(selected === mesh));
    button.dataset.part = mesh.uuid;
    button.addEventListener('click', () => selectPart(mesh));
    return button;
  });
  $('part-list').replaceChildren(...buttons);
}

function clearSelection() {
  if (selected) {
    const materials = Array.isArray(selected.material) ? selected.material : [selected.material];
    materials.forEach(mat => {
      if (mat.userData.originalEmissive && mat.emissive) mat.emissive.copy(mat.userData.originalEmissive);
      if (mat.userData.originalEmissiveIntensity !== undefined) mat.emissiveIntensity = mat.userData.originalEmissiveIntensity;
    });
  }
  selected = null;
  $('annotation').hidden = true;
  $('selection-hint').hidden = false;
  document.querySelectorAll('.part-button').forEach(button => button.setAttribute('aria-pressed', 'false'));
}

function selectPart(mesh) {
  clearSelection();
  selected = mesh;
  const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
  materials.forEach(mat => { if (mat.emissive) { mat.emissive.set('#7c9259'); mat.emissiveIntensity = .14; } });
  const meta = mesh.userData.spec;
  $('part-name').textContent = meta.name;
  $('part-type').textContent = meta.group || 'Selected component';
  $('part-notes').textContent = textValue(meta.notes) || textValue(meta.role) || 'Geometry reconstructed for assembly inspection.';
  $('part-source').textContent = `Source: ${textValue(meta.source) || 'Design assumption; no dimension specified.'}`;
  $('part-dim').textContent = `Part envelope: ${dimensions(measure(mesh))} mm`;
  $('annotation').hidden = false;
  $('selection-hint').hidden = true;
  document.querySelectorAll('.part-button').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.part === mesh.uuid)));
  $('live-status').textContent = `Selected ${meta.name}. ${textValue(meta.notes)}`;
}

function visibility() {
  const allowed = views[focus].groups;
  parts.forEach(mesh => {
    const partGroup = String(mesh.userData.spec.group).toLowerCase();
    const matching = allowed.some(group => {
      const allowedGroup = group.toLowerCase();
      return partGroup === allowedGroup || (allowedGroup === 'hub' && partGroup.startsWith('hub '));
    });
    mesh.visible = matching && (showShells || !isShell(mesh));
  });
  visibleParts = parts.filter(mesh => mesh.visible);
  if (selected && !selected.visible) clearSelection();
  updatePartList(); updateFacts();
}

function frame(instant = false) {
  if (!visibleParts.length) return;
  const box = currentBox(), size = box.getSize(new THREE.Vector3()), center = box.getCenter(new THREE.Vector3());
  const radius = size.length() * .5;
  const verticalFov = THREE.MathUtils.degToRad(camera.fov);
  const horizontalFov = 2 * Math.atan(Math.tan(verticalFov / 2) * camera.aspect);
  const direction = new THREE.Vector3(...(focus === 'system' ? [.13, .15, 1] : focus === 'cable' ? [.55, .5, 1] : [.65, .42, 1])).normalize();
  // Keep the object left of the floating controls, while retaining its full inspection envelope.
  const target = center.clone();
  if (innerWidth > 850 && focus !== 'system') target.x += size.x * .12;
  const right = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 1, 0), direction).normalize();
  const up = new THREE.Vector3().crossVectors(direction, right).normalize();
  const padding = innerWidth <= 850 ? 1.10 : 1.43;
  let distance = .008;
  // Fit the projected box rather than a sphere: tall earbuds can use the full
  // narrow viewport without treating their height as an equally wide object.
  for (const x of [box.min.x, box.max.x]) for (const y of [box.min.y, box.max.y]) for (const z of [box.min.z, box.max.z]) {
    const corner = new THREE.Vector3(x, y, z).sub(target);
    const projectedX = Math.abs(corner.dot(right)), projectedY = Math.abs(corner.dot(up));
    const needed = corner.dot(direction) + Math.max(projectedX / Math.tan(horizontalFov / 2), projectedY / Math.tan(verticalFov / 2)) * padding;
    distance = Math.max(distance, needed);
  }
  const destination = target.clone().addScaledVector(direction, distance);
  camera.near = Math.max(.000005, distance / 1000); camera.far = Math.max(4, distance * 30); camera.updateProjectionMatrix();
  controls.minDistance = Math.max(.001, radius * .18);
  controls.maxDistance = Math.max(.3, radius * 16);
  if (instant || reducedMotion) { camera.position.copy(destination); controls.target.copy(target); controls.update(); transition = null; }
  else transition = { start: performance.now(), from: camera.position.clone(), to: destination, fromTarget: controls.target.clone(), toTarget: target };
}

function setFocus(next, instant = false) {
  focus = next;
  clearSelection();
  focusButtons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.focus === focus)));
  $('view-title').textContent = views[focus].title;
  $('view-subtitle').textContent = views[focus].subtitle;
  $('view-number').textContent = views[focus].number;
  visibility(); frame(instant);
  $('live-status').textContent = `${views[focus].title}, ${visibleParts.length} visible parts.`;
}

function setExplosion(value) {
  explosion = value;
  $('explode-output').textContent = `${Math.round(value * 100)}%`;
  parts.forEach(mesh => {
    const offset = mesh.userData.spec.explode || [0, 0, 0];
    const base = basePositions.get(mesh.uuid);
    if (Array.isArray(offset) && offset.length >= 3) mesh.position.copy(base).add(new THREE.Vector3(...offset).multiplyScalar(value * .001));
  });
  model.updateMatrixWorld(true);
  updateFacts();
  if (selected) $('part-dim').textContent = `Part envelope: ${dimensions(measure(selected))} mm`;
}

function init() {
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.setClearColor(0x000000, 0);
    renderer.domElement.setAttribute('aria-label', 'Interactive technical model. Drag to orbit; scroll or pinch to zoom; choose a part from the list for accessible inspection.');
    renderer.domElement.setAttribute('role', 'img');
    renderer.domElement.tabIndex = 0;
    container.append(renderer.domElement);
    scene = new THREE.Scene();
    scene.environment = studioEnvironment();
    scene.environmentIntensity = .65;
    scene.add(new THREE.HemisphereLight(0xf9faf5, 0x667061, .65));
    const key = new THREE.DirectionalLight(0xfffaf0, 2); key.position.set(.25, .4, .5); scene.add(key);
    const fill = new THREE.DirectionalLight(0xe4edff, .65); fill.position.set(-.4, .05, .1); scene.add(fill);
    const rim = new THREE.DirectionalLight(0xffffff, 1.3); rim.position.set(.1, .2, -.5); scene.add(rim);
    camera = new THREE.PerspectiveCamera(32, container.clientWidth / container.clientHeight, .00001, 10);
    camera.position.set(.07, .055, .09);
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.dampingFactor = .09; controls.enablePan = true;
    controls.rotateSpeed = .72; controls.zoomSpeed = .7; controls.panSpeed = .75;
    controls.addEventListener('start', () => { transition = null; });
    renderer.domElement.addEventListener('webglcontextlost', event => { event.preventDefault(); fail('The 3D rendering session was interrupted. Reload this page to restore the model. The CAD files are still available below.'); });
  } catch (error) {
    fail('This browser could not start the 3D viewer. Open the STEP or FreeCAD model to inspect the complete assembly.', error); return;
  }

  const loader = new GLTFLoader();
  loader.load('./assembly.glb', gltf => {
    model = gltf.scene; scene.add(model);
    model.traverse(node => {
      if (!node.isMesh) return;
      const spec = metadata(node);
      node.userData.spec = spec;
      node.frustumCulled = true;
      const materialArray = Array.isArray(node.material) ? node.material : [node.material];
      const clones = materialArray.map(material => {
        const mat = material.clone();
        mat.side = THREE.DoubleSide;
        mat.envMapIntensity = .9;
        if (mat.emissive) mat.userData.originalEmissive = mat.emissive.clone();
        mat.userData.originalEmissiveIntensity = mat.emissiveIntensity;
        return mat;
      });
      node.material = Array.isArray(node.material) ? clones : clones[0];
      parts.push(node); basePositions.set(node.uuid, node.position.clone());
    });
    if (!parts.length) { fail('The model contains no inspectable geometry. The original CAD downloads remain available below.'); return; }
    model.updateMatrixWorld(true);
    setFocus('left', true);
    if (!visibleParts.length) setFocus('system', true);
    $('loading').hidden = true;
    window.__cymbaViewer = { get parts() { return parts; }, get focus() { return focus; }, get visibleParts() { return visibleParts; }, setFocus, setExplosion, frame, renderer, scene, camera, controls };
  }, event => {
    if (event.total) $('loading-text').textContent = `Preparing the technical model… ${Math.round(event.loaded / event.total * 100)}%`;
  }, error => fail(location.protocol === 'file:' ? 'To view the interactive model, open this folder through a local web server. The STEP and FreeCAD downloads also open directly in CAD software.' : 'The 3D model could not be loaded. Check that assembly.glb is beside this page, then reload. The CAD files are available below.', error));

  focusButtons.forEach(button => button.addEventListener('click', () => { if (model) setFocus(button.dataset.focus); }));
  $('explode').addEventListener('input', event => { if (model) setExplosion(Number(event.target.value) / 100); });
  $('explode').addEventListener('change', () => { if (model) frame(); });
  $('shell-toggle').addEventListener('click', () => {
    if (!model) return;
    showShells = !showShells;
    $('shell-toggle').setAttribute('aria-checked', String(showShells));
    visibility();
  });
  $('reset').addEventListener('click', () => {
    if (!model) return;
    showShells = true; $('shell-toggle').setAttribute('aria-checked', 'true');
    $('explode').value = '0'; setExplosion(0); clearSelection(); visibility(); frame();
  });
  $('close-selection').addEventListener('click', clearSelection);
  window.addEventListener('keydown', event => { if (event.key === 'Escape') clearSelection(); });
  container.addEventListener('pointerdown', event => { pointerStart = { x: event.clientX, y: event.clientY, time: performance.now() }; });
  container.addEventListener('pointerup', event => {
    if (!model || !pointerStart || event.button !== 0) return;
    const movement = Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y);
    if (movement > 6 || performance.now() - pointerStart.time > 550) return;
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
    raycaster.setFromCamera(pointer, camera);
    const hit = raycaster.intersectObjects(visibleParts, false)[0];
    if (hit) selectPart(hit.object); else clearSelection();
  });
  let previousViewport = [container.clientWidth, container.clientHeight];
  const resize = new ResizeObserver(() => {
    const width = container.clientWidth, height = container.clientHeight;
    if (!width || !height) return;
    camera.aspect = width / height; camera.updateProjectionMatrix(); renderer.setSize(width, height);
    if (model && (Math.abs(width - previousViewport[0]) > 2 || Math.abs(height - previousViewport[1]) > 2)) frame(true);
    previousViewport = [width, height];
  });
  resize.observe(container);
  function render(now) {
    requestAnimationFrame(render);
    if (transition) {
      const t = Math.min(1, (now - transition.start) / 560), ease = 1 - (1 - t) ** 3;
      camera.position.lerpVectors(transition.from, transition.to, ease);
      controls.target.lerpVectors(transition.fromTarget, transition.toTarget, ease);
      if (t === 1) transition = null;
    }
    controls.update();
    inverseCamera.copy(camera.quaternion).invert();
    axes.forEach(axis => {
      axisVector.copy(axis.vector).applyQuaternion(inverseCamera);
      axis.line.setAttribute('x2', 30 + axisVector.x * 20);
      axis.line.setAttribute('y2', 30 - axisVector.y * 20);
      axis.label.setAttribute('x', 30 + axisVector.x * 25);
      axis.label.setAttribute('y', 33 - axisVector.y * 25);
      axis.line.style.opacity = .45 + (axisVector.z + 1) * .25;
      axis.label.style.opacity = .6 + (axisVector.z + 1) * .2;
    });
    renderer.render(scene, camera);
  }
  requestAnimationFrame(render);
}

updateFacts();
init();
